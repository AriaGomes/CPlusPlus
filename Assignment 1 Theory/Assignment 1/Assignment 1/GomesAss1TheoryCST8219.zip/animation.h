//Animation.h
#pragma once

class Animation
{
public:
	char* animationName;
	Frame* frames;
	Animation();
	~Animation();
	void InsertFrame();
	void EditFrame();
	void DeleteFrame();
	void ReportAnimation();
	void ReportLength();
	int Length(Frame* f);
	Animation* CopyList(Animation& oldAnim);
};
